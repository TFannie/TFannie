#include"queue.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void main2();
int main()
{
	int i=0,data1,j;
	char data2;
	float data3;
	double data4;
	AQueue *q=(AQueue *)malloc(sizeof(AQueue));    //������ָ��Ľṹ������ڴ棬������ָ��ĵ�ַ�ڴ棬�ýṹ���СΪ52
	InitAQueue(q);
	while (true)
	{
		printf("Do you want to operate?Yes(1)  No(0):");
		j=scanf_s("%d", &i); while (getchar()!='\n');
		if (j < 1)goto A;
		if (i == 1)
		{
	A:		printf("enter queue:what kind data do you want to enter:(1)int  (2)char  (3)float  (4)double:");
			j=scanf_s("%d", &i); while (getchar() != '\n'); 
			if (j < 1)goto A;
			if (!IsEmptyAQueue(q) && !IsFullAQueue(q))mark[(q->rear + 1)%MAXQUEUE] = i;
			else if (IsEmptyAQueue(q))mark[q->rear] = i;
			printf("write down data:\n");
			switch (i)
			{
			case 1:  
				      j=scanf_s("%d", &data1); while (getchar() != '\n');
					  if (j < 1)goto A;
				      EnAQueue(q, &data1); break;

			case 2:   
				      j=scanf_s("%c", &data2); while (getchar() != '\n');
					  if (j < 1)goto A;
					  EnAQueue(q, &data2); break;

			case 3:  
				      j=scanf_s("%f", &data3); while (getchar() != '\n');
					  if (j < 1)goto A;
				      EnAQueue(q, &data3); break;

			case 4:  
				      j=scanf_s("%lf", &data4); while (getchar() != '\n');
					  if (j < 1)goto A;
				      EnAQueue(q, &data4); break;
			default:continue;
			}

		   printf("what to delete?YES(1)  No(other):");
			j=scanf_s("%d", &i); while (getchar() != '\n');
			if (j < 1)goto A;
			if (i == 1)
			{
				DeAQueue(q);
			}
		}
		else break;
	}
	printf("�����������£�\n");
    printf("q->data_size:%d\n", q->data_size);
	TraverseAQueue(q, APrint);
	printf("q->front:%d\n", q->front);
	printf("q->rear:%d\n", q->rear);
	printf("���г��ȣ�%d\n",LengthAQueue(q));
	ClearAQueue(q);
	printf("��ն������");
	printf("\n\n����Ϊ��ʽ���У���\n\n");
	main2();
	system("pause");
	return 0;
}

void main2()
{
	LQueue *q=(LQueue *)malloc(sizeof(LQueue));
	Node *f, *r;
	int i = 0, data1,j;
	char data2;
	float data3;
	double data4;
	f = r = nullptr;
	InitLQueue(q);
    while (true)
		{
			printf("Do you want to operate?Yes(1)  No(0):");
		A:	j=scanf_s("%d", &i); while (getchar() != '\n');
			if (j < 1)goto A;
			if (i == 1)
			{
				printf("enter queue:what kind data do you want to enter:(1)int  (2)char  (3)float  (4)double:");
				j=scanf_s("%d", &i); while (getchar() != '\n');
				if (j < 1)goto A;
				if (!IsEmptyLQueue(q))link[(i_r+1) %100] = i;
				else if (IsEmptyLQueue(q))link[i_r] = i;
				printf("write down data:");
				switch (i)
				{
				case 1:
					j=scanf_s("%d", &data1); while (getchar() != '\n');
					if (j < 1)goto A;
					EnLQueue(q, &data1); break;

				case 2:
					j=scanf_s("%c", &data2); while (getchar() != '\n');
					if (j < 1)goto A;
					EnLQueue(q, &data2); break;

				case 3:
					j=scanf_s("%f", &data3); while (getchar() != '\n');
					if (j < 1)goto A;
					EnLQueue(q, &data3); break;

				case 4:
					j=scanf_s("%lf", &data4); while (getchar() != '\n');
					if (j < 1)goto A;
					EnLQueue(q, &data4); break;
				default:continue;
				}
				printf("what to delete?YES(1)  No(other):");
				j=scanf_s("%d", &i); while (getchar() != '\n');
				if (j < 1)goto A;
				if (i == 1)
				{
					DeLQueue(q);
				}
			}
			else break;
		}
		printf("�����������£�\n");
		printf("q->data_size:%d\n", q->data_size);
		TraverseLQueue(q, APrint);
		printf("front:%d\n", i_f);
		printf("rear:%d\n", i_r);
		printf("���г��ȣ�%d\n", LengthLQueue(q));
		ClearLQueue(q);
		printf("��ն������");
		printf("\n\n����Ϊ��ʽ���У���\n\n");

}