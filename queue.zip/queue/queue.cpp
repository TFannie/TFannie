#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "queue.h"

int mark[10] = { 0 };//λ������1Ϊint ��2Ϊchar��3Ϊfloat��4Ϊdouble
int local;      //��������Ϊ˳����е�

int link[100] = { 0 };
int i_f=0, i_r=0;
void InitAQueue(AQueue * Q)  //���˿�ʼ��front��rear�������
{
	int i = 0;
	Q->front = Q->rear = 0;
	Q->data_size = 0;
	while (i < MAXQUEUE)
	{
		Q->data[i] = nullptr;
		i++;
	}
}

void InitLQueue(LQueue * Q)
{
	Q->front=Q->rear=nullptr;
	Q->data_size = 0;
}

void DestoryAQueue(AQueue * Q)  //��ֹ�ڴݻٶ���ʱ���ڴ����
{
	if (Q->front < Q->rear)
	{
		while (Q->front <= Q->rear)
		{
			free(Q->data[Q->front]);
			Q->front++;
		}
	}
	else if (Q->front == Q->rear)
	{
		if (Q->data_size > 0)
			free(Q->data[Q->front]);
	}
    else if (Q->front > Q->rear)
    {
		  while (Q->front % 10 != Q->rear)
		{
			free(Q->data[Q->front % 10]);
			Q->front++;
		}
		free(Q->data[Q->rear]);
	}

	free(Q);
	Q = nullptr;
}

void DestoryLQueue(LQueue * Q)
{
	Node *temp;
	while (Q->front != Q->rear)
	{
		temp = Q->front->next;

		free(Q->front);
		Q->front = temp;
	}
	if (Q->front != nullptr)
	{
		free(Q->front);
		Q->front = Q->rear = nullptr;
	}
	free(Q); 
	Q = nullptr;
}

Status IsFullAQueue(const AQueue * Q)
{
	if ((Q->front == Q->rear+1)||(Q->front==Q->rear-9))   //����������ж���
	return TRUE;
	
	else return FLASE;
}

Status IsEmptyAQueue(const AQueue * Q)
{
	if(Q->data_size==0||Q==nullptr)return TRUE;
	else return FLASE;
}

Status IsEmptyLQueue(const LQueue * Q)
{
	if (Q->data_size == 0||Q==nullptr)return TRUE;
	else return FLASE;
}

Status GetHeadAQueue(AQueue * Q, void * e)
{
	if (IsEmptyAQueue(Q))return FLASE;
	switch (mark[Q->front])
	{
	case 1:memcpy_s(e, sizeof(int), Q->data[Q->front], sizeof(int)); break;
	case 2:memcpy_s(e, sizeof(char), Q->data[Q->front], sizeof(char)); break;
	case 3:memcpy_s(e, sizeof(float), Q->data[Q->front], sizeof(float)); break;
	case 4:memcpy_s(e, sizeof(double), Q->data[Q->front], sizeof(double)); break;
	default:return FLASE;
	}
	return TRUE;
}

Status GetHeadLQueue(LQueue * Q, void * e)
{
	Node *front = Q->front;
	if (IsEmptyLQueue(Q))return FLASE;
	switch (link[i_f])
	{
	case 1:memcpy_s(e, sizeof(int), front->data, sizeof(int)); break;
	case 2:memcpy_s(e, sizeof(char), front->data, sizeof(char)); break;
	case 3:memcpy_s(e, sizeof(float), front->data, sizeof(float)); break;
	case 4:memcpy_s(e, sizeof(double),front->data, sizeof(double)); break;
	default:return FLASE;
	}
	return TRUE;
}

int LengthAQueue(AQueue * Q)
{
	if (IsEmptyAQueue(Q))return 0;
	if (Q->rear >= Q->front)return (Q->rear - Q->front + 1);
	if (Q->rear < Q->front)return (MAXQUEUE-(Q->front-Q->rear-1));
}

int LengthLQueue(LQueue * Q)
{
	if (IsEmptyLQueue(Q))return 0;
	else if (i_f == i_r)return 1;
	else if (i_f < i_r)return i_r - i_f + 1;
	else if (i_f > i_r)return 100 - (i_f - i_r - 1);
}

Status EnAQueue(AQueue * Q, void * data)//��Ӳ���,*dataΪ��Ӷ���,�ڸñ���ָ�봫����֮ǰ��Ӧ��ͨ��markȷ���������������,��ʱQ��δ֪�Ƿ���ɶ�Q->frontû�б仯
{
	size_t large;
	if (IsFullAQueue(Q))return FLASE;  //rear��
	if(!IsEmptyAQueue(Q))Q->rear++;
     Q->rear = (Q->rear)%MAXQUEUE;
	switch (mark[Q->rear])
	{
	case 1:   Q->data_size += (large=sizeof(int));
		      Q->data[Q->rear] = (int *)malloc(sizeof(int)); break;

	case 2:   Q->data_size += (large=sizeof(char));
		      Q->data[Q->rear] = (char *)malloc(sizeof(char)); break;

	case 3:   Q->data_size += (large=sizeof(float));
		      Q->data[Q->rear] = (float *)malloc(sizeof(float)); break;

	case 4:   Q->data_size += (large=sizeof(double));
		      Q->data[Q->rear] = (double *)malloc(sizeof(double)); break;
	default:return FLASE;
	}
	memcpy_s(Q->data[Q->rear], large, data, large);  //ע�⣡��memcpy_s������Ϊ��Ҫ�������ֽ������״�
	return TRUE;
}

Status EnLQueue(LQueue * Q, void * data)  //mistake

{
	size_t large;
	Node *e=Q->rear;

	if (!IsEmptyLQueue(Q))i_r++;
	i_r = (i_r) % 100;
	e = (Node *)malloc(sizeof(Node));
	if (IsEmptyLQueue(Q))
	{
		Q->front=Q->rear = e;
	}
	else
	{
	   Q->rear->next = e;
    }
	switch (link[i_r])
	{
	case 1:   Q->data_size += (large = sizeof(int));
		      e->data = (int *)malloc(sizeof(int)); break;

	case 2:   Q->data_size += (large = sizeof(char));
		      e->data = (char *)malloc(sizeof(char)); break;

	case 3:   Q->data_size += (large = sizeof(float));
		      e->data = (float *)malloc(sizeof(float)); break;

	case 4:   Q->data_size += (large = sizeof(double));
		      e->data = (double *)malloc(sizeof(double)); break;
	default:return FLASE;
	}
	memcpy_s(e->data, large, data, large);  //ע�⣡��memcpy_s������Ϊ��Ҫ�������ֽ������״�
	Q->rear->next = nullptr;
	return TRUE;
}

Status DeAQueue(AQueue * Q)  // ���Ӳ���
{
	if (IsEmptyAQueue(Q)==TRUE)
		return FLASE;
	switch (mark[Q->front])
	{
	case 1:     Q->data_size -= sizeof(int); break;   //���Ǽ���break����
	case 2:     Q->data_size -= sizeof(char); break;
	case 3:     Q->data_size -= sizeof(float); break;
	case 4:     Q->data_size -= sizeof(double); break;
	default:    return FLASE;
	}
	free(Q->data[Q->front]);
	Q->data[Q->front] = nullptr;
	if (Q->front == Q->rear)
		Q->front = Q->rear = 0;
	else
		Q->front = (Q->front + 1) % MAXQUEUE;
	return TRUE;
}

Status DeLQueue(LQueue * Q)
{
	Node *q=Q->front;
	if (IsEmptyLQueue(Q) == TRUE)
		return FLASE;
	switch (link[i_f])
	{
	case 1:       Q->data_size -= sizeof(int); break;   //���Ǽ���break����
	case 2:       Q->data_size -= sizeof(char); break;
	case 3:       Q->data_size -= sizeof(float); break;
	case 4:       Q->data_size -= sizeof(double); break;
	default:      return FLASE;
	}
	Q->front = Q->front->next;
	free(q);
	i_f = (i_f + 1) % 100;
	return TRUE;
}

void ClearAQueue(AQueue * Q)//��ն���
{
	for (int i = 0; i < 10; i++)
	{
		if (Q->data[i] != nullptr)
		{
			free(Q->data[i]);
			Q->data[i] = nullptr;
		}
	}
	Q->front = Q->rear = Q->data_size = 0;
}

void ClearLQueue(LQueue * Q)
{
	Node *q;
	if (!IsEmptyLQueue(Q))
	{
		while (Q->front != Q->rear)
		{
			q = Q->front;
			Q->front = Q->front->next;
			free(q);
		}
		free(Q->front);
		Q->front = Q->rear = nullptr;
		Q->data_size == 0;
	}
	   i_f = i_r = 0;
}

Status TraverseAQueue(const AQueue * Q, void(*foo)(void *q))//������������,foo������APrint�ĺ���ָ�룬�ǵ��ã�*foo��()����foo()���ǿ��Ե�
{
	int tf = Q->front, tr = Q->rear;
	if (IsEmptyAQueue(Q))return FLASE;
	if (tf <= tr)
	{
		while (tf <= tr)
		{
			local = tf;               //����foo��APrintһ��λ���ж�����
			foo(Q->data[tf]);
			tf++;
		}
	}
	else
	{
		while ((tf%MAXQUEUE) != tr)
		{
			local = tf % MAXQUEUE;
			foo(Q->data[tf]);
			tf++;
		}
		local = tf % MAXQUEUE;
		foo(Q->data[tf]);
	}
	return TRUE;
}

Status TraverseLQueue(const LQueue * Q, void(*foo)(void *q))
{
	int tf = i_f, tr = i_r;
	if (IsEmptyLQueue(Q))return FLASE;
	if (tf <= tr)
	{
		while (tf <= tr)
		{
			local = tf;               //����foo��APrintһ��λ���ж�����
			foo(Q->front->data);
			tf++;
		}
	}
	else
	{
		while ((tf%100) != tr)
		{
			local = tf % 100;
			foo(Q->front->data);
			tf++;
		}
		local = tf % MAXQUEUE;
		foo(Q->front->data);
	}
	return TRUE;
}

void APrint(void * q)//��������,��Ҫ��֪(local)λ��mark��һ��λ��
{
	switch (mark[local])
	{
	case 1:printf("%d\n", *(int *)q); break;  //�������Ϳ��Դ���void *����void *���ɴ����������͡�void���Խ���ǿ������ת��
	case 2:printf("%c\n", *(char *)q); break;
	case 3:printf("%f\n", *(float *)q); break;
	case 4:printf("%lf\n", *(double *)q); break;
	default:break;
	}
}

void LPrint(void * q)
{
	switch (link[local])
	{
	case 1:printf("%d\n", *(int *)q); break;  //�������Ϳ��Դ���void *����void *���ɴ����������͡�void���Խ���ǿ������ת��
	case 2:printf("%c\n", *(char *)q); break;
	case 3:printf("%f\n", *(float *)q); break;
	case 4:printf("%lf\n", *(double *)q); break;
	default:break;
	}
}
